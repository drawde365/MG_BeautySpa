﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MGBeautySpaWebAplication.Empleado
{
    public class HorarioRow
    {
        public string Hora { get; set; }
        public bool Lunes { get; set; }
        public bool Martes { get; set; }
        public bool Miercoles { get; set; }
        public bool Jueves { get; set; }
        public bool Viernes { get; set; }
        public bool Sabado { get; set; }
    }
}