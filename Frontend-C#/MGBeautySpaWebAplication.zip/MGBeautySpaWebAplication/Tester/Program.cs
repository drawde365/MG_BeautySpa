﻿using SoftInvBusiness;

ProductoBO productoBO = new ProductoBO();
var producto = productoBO.buscarPorNombre("Crema");